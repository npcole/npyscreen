#!/usr/bin/python

"""
Documentation (very basic)!

There are two elements to this library.

Firstly there are a few objects for handling
screen areas.  These objects are essentially curses_pads, which can be larger
than the screen, but with set up so that they handle screen re-sizing nicely and
refreshing their area nicely.  A future revision would scroll the screen area
shown automatically when the user moves into widgets that are out of sight,
though the current version does not do that.  However, the hooks for doing so
are in place.  

The Object you want to use is the Form object, which knows how to handle widgets
and user inputs.

The second element is the widgets themselves.  These expect to live their happy
lives on a Form object, or the lower-level object defined in screen_area.

To add wigets to a Form object, call the add_widget method, passing in a class
of widget and any options.

###################################################################################
				Curses wrapping

npyscreen exposes curses.wrapper as npyscreen.wrapper

This is for convenience more than anything else, although in the future the
npymenus.wrapper may act differently.

npymenus.wrapper(function ... ) 

sets up your terminal for curses, and ensures that in the event of an error, the
terminal is returned to normal.  See the curses.wrapper documentation for more
details.

####################################################################################
				Widget types:


Textfield and TitleText  	# Allow the user to enter a text string.  Use
				# the TitleText version and give it a name.

PasswordEntry and TitlePassword

Slider and TitleSlider		# accepts the options out_of= and step=
				# You can also change the text displayed by the
				# Titled version, by subclassing it and
				# overriding the translate_value method to
				# return a differnt string.

Button				# A button.
CheckBox			# Um. Yes. Same functionality as a button,
				# really, but they look different.

ComboBox			# Displayed as one line of text, but let the
				# user select its value from a list.

DisplayLines			# This should really be called SelectLine.  It's
				# quite powerful, really.

MultiSelect			# select more than one thing.

ScrollLines			# Acts like a pager.  See the Function ViewText

FileName and TitleFileName	# Half Textbox, half combobox.  Tab Completion,
				# and everything.  
				#
				# To make similar widgets, look at how it
				# subclasses the type on which it is based
				# (textfield.AutoComplete) which is not exposed
				# by the module when loaded because as it
				# stands, it is fairly useless....but as
				# FileName shows, that can change!


####################################################################################
				User Input

When a widget is selected for editing, any user key presses are handled using
the method defined in the widget.InputHandler class (though widgets can override
all aspects of this.

1. The input is looked up in a dictionary (self.handlers).  If this dictionary
specifies a function to handle the input this is called.

2. If lookup fails, the input is then handled by checking the
self.complex_handlers list.  This list looks like [(test_function, handler
function), ....]

Each test_function is passed the input in turn, and if it returns True, the
handler function is called.

If both of these fail, the input is passed to the widget's parent (i.e. the form
it is sitting on), which can handle the input in the same way.

If all of this has failed nothing happens.  If any step succeeds, processing
stops there.

The handlers are set up in the set_up_handlers method of each class.
######################################################################################
				Options

For a full list of options, see each class.  The following are most useful,
though.  The following keyword arguments at object creation time are useful,
though.

name=      # The name or title of the widget.
relx= 
rely=      #  Where do you want it on the screen.  Often you don't need this at
		all, since add_widget will make a guess for you.

For widgets with variable sizes, the following are useful, and will be honoured
where possible.

max_height=     # Some widgets will take all available remaining screen space,
max_width=	#unless you stop them.

request_height= #For variable height widgets.
request_width=

The Titled Widgets (ie. those which display their name to the user) accept:

begin_entry_at= # The column that the business end of the widget should start
			in.

field_width_request= # Usually not needed. Does what it says.

All constuctors also allow the widget value to be set at creation time:

value= 
values= # For some widgets: see next section.

########################################################################################
				Values

Every widget has a self.value

Widgets that allow the user to select from several options hold these options in
self.value, and the choice the user made in self.values

#########################################################################################
				Edit Methods

To allow the user to edit a widget, call it's edit() method.

To edit all wigets on a form, try the form's edit() method.

Simple, yes?  Whichever you do depends on circumstances.  For example you might
build a form with lots of text entry widgets and want the user to be able to
step through them.  Or you might have a display where you update all the fields
based on what the user has entered in a single field, so you might want to let
the user just edit that one.  It's all pretty flexible, and up to you.

The Form class adds an "OK" button in the bottom right corner when it is being
edited, so that the user can say that he's finished.

##########################################################################################
				Convenience Functions:

The function ViewText(text) acts like a pager.

The function MakeChoice(choices) is good too.

The function MakeMultChoice(choices) is great.

All are good examples of writing a quick form, so have a look at them.

##########################################################################################



"""


import curses.wrapper as wrapper

from Screen import _Form, Form

from button import Button, CheckBox

from textfield import Textfield, TitleText, PasswordEntry, \
			TitlePassword, ComboBox, TitleCombo

from slider import Slider, TitleSlider

from select import DisplayLines, ScrollLines, MultiSelect, ViewText, MakeChoice, MakeMultiChoice

from filename import FileName, TitleFileName

from multitext import MultiLineText, StringToEditor # The latter is a function.

from pmfuncs import CallSubShell
