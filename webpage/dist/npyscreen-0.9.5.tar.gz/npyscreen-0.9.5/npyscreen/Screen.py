#!/usr/bin/python

import gc
import curses

import screen_area
import weakref
import widget
import button
import select
import gc

"""A high-level object.  Contains objects for creating screens and popups"""

class Form(object):
	"""Class to draw a display on the screen and allow the user to interact
	with it.  The two calls you will want to use most often are:

	.addwidget(wigetClass .....)

	which puts a widget on the screen, and

	edit()

	which allows the user to edit the display."""
	
	def __init__(self, *args, **keywords):
		self.__dict__['_Form__screen'] = _Form(*args, **keywords)
		
	def __del__(self):
		self.__screen.destroy()
		#del self.__screen
		self.__dict__['_Form__screen'] = None
		
	def __getattr__(self, name):
		if hasattr(self.__screen, name): return getattr(self.__screen, name)
		else: raise AttributeError, "Form object has no attribute %s" % name

	def __setattr__(self, name, value):
		setattr(self.__screen, name, value)

class _Form(screen_area.ScreenArea, widget.InputHandler):
	# store everything 

	"""A class for creating screens of widgets. Do not use this class directly, 
but use the wrapper class Form instead.  If inheriting from this class, pay particular 
attention to the destroy() method."""

	def __init__(self, name=None, framed=True, help=None, *args, **keywords):
		super(_Form, self).__init__(*args, **keywords)

		self.framed = framed
		self.name=name
		self.editing = False
		self.__widgets= []

		self.nextrely = 2
		self.nextrelx = 2
		self.editw = 0 # Index of widget to edit.

		self.help = help

		self.set_up_handlers()
		self.set_up_exit_condition_handlers()
	
	def set_up_handlers(self):
		self.complex_handlers = []
		self.handlers = { 
					curses.KEY_F1: self.h_display_help,
					"KEY_F(1)": self.h_display_help,
					"!h":	    self.h_display_help,
					}

	def set_up_exit_condition_handlers(self):
		# What happens when widgets exit?
		# each widget will set it's how_exited value: this should
		# be used to look up the following table.
		
		self.how_exited_handers = {
			widget.EXITED_DOWN: self.find_next_editable,
			widget.EXITED_UP:   self.find_previous_editable,
			True:	            self.find_next_editable, # A default value
			}

	def handle_exiting_widgets(self, condition):
		self.how_exited_handers[condition]()

	def on_screen(self):
		# is the widget in editw on sreen at the moment?
		# if not, alter screen so that it is.
		w = weakref.proxy(self.__widgets[self.editw])
		
		max_y, max_x = self._max_physical()

		w_my, w_mx = w.calculate_area_needed()
		
		# always try to show the top of the screen.
		self.show_from_y = 0
		self.show_from_x = 0
		
		while w.rely + w_my -1 > self.show_from_y + max_y:
			self.show_from_y += 1

		while w.rely < self.show_from_y:
			self.show_from_y -= 1

		while w.relx + w_mx -1 > self.show_from_x + max_x:
			self.show_from_x += 1

		while w.relx < self.show_from_x:
			self.show_from_x -= 1
		
		
		
	def edit(self):
		"""Edit the fields until the user selects the ok button added in the lower right corner. Button will
		be removed when editing finishes"""
		self.editing=True
		if self.editw < 0: self.editw=0
		if self.editw > len(self.__widgets)-1:
			self.editw = len(self.__widgets)-1
	
		if not self.__widgets[self.editw].editable: self.find_next_editable()
		# Add ok button. Will remove later
		tmp_rely, tmp_relx = self.nextrely, self.nextrelx
		my, mx = self.curses_pad.getmaxyx()
		ok_button_text = "OK"
		my -= 3
		mx -= len(ok_button_text)+6
		ok_button = self.add_widget(button.Button, name=ok_button_text, rely=my, relx=mx)
		ok_button.update()

		self.display()

		while not self.__widgets[self.editw].editable:
			self.editw += 1
			if self.editw > len(self.__widgets)-1: return False
		
		while self.editing:
			if not self.ALL_SHOWN: self.on_screen()
			self.__widgets[self.editw].edit()
			self.__widgets[self.editw].display()
			
			self.handle_exiting_widgets(self.__widgets[self.editw].how_exited)
			
			if self.editw > len(self.__widgets)-1: self.editw = len(self.__widgets)-1
			if ok_button.value:
				self.editing = False
				ok_button.destroy()
				self.__widgets = self.__widgets[:-1]
				del ok_button
				self.rely, self.relx = tmp_rely, tmp_relx
				self.display()

		self.editing = False
			
	
	def h_display_help(self, input):
		if self.help == None: return
		if self.name:
			help_name="%s Help" %(self.name)
		else: help_name=None
		curses.flushinp()
		select.ViewText(self.help, name=help_name)
		self.display()
		return True
			
	def find_next_editable(self, *args):
		if not self.editw == len(self.__widgets):		
			for n in xrange(self.editw+1, len(self.__widgets)):
				if self.__widgets[n].editable: 
					self.editw = n
					break
		self.display()

	def find_previous_editable(self, *args):
		if not self.editw == 0:		
			# remember that xrange does not return the 'last' value,
			# so go to -1, not 0! (fence post error in reverse)
			for n in xrange(self.editw-1, -1, -1 ):
				if self.__widgets[n].editable: 
					self.editw = n
					break

	def display(self):
		self.curses_pad.erase()
		if self.framed:
			self.curses_pad.border()
			
			try:
				if self.name:
					self.curses_pad.addstr(0,1, ' '+str(self.name)+' ')
			except:
				pass

			if self.help and self.editing:
				try:
					help_advert = " Help: F1 or M-h "
					self.curses_pad.addstr(
					 0, self.curses_pad.getmaxyx()[1]-len(help_advert)-2, help_advert 
					 )
				except:
					pass
			

		for w in self.__widgets: w.update()
		
		self.refresh()

	def add_widget(self, widgetClass, max_height=False, rely=None, relx=None, *args, **keywords):
		"""Add a widget to the form.  The form will do its best to decide on placing, unless you override it.
		The form of this function is add_widget(WidgetClass, ....) with any arguments or keywords supplied to
		the widget. The wigdet will be added to self.__widgets
		
		It is safe to use the return value of this function to keep hold of the widget, since that is a weak
		reference proxy, but it is not safe to keep hold of self.__widgets"""

		if rely is None:
			rely = self.nextrely
		if relx is None:
			relx = self.nextrelx

		if max_height is False:
			max_height = self.curses_pad.getmaxyx()[0] - rely - 1

		_w = widgetClass(self, rely=rely, relx=relx, 
				max_height=max_height, 
				*args, **keywords)
		
		self.nextrely=_w.calculate_area_needed()[0]
		self.__widgets.append(_w)

		return weakref.proxy(_w)
	
	def destroy(self):
		"""When a from is finished with, this method MUST be called, followed by a del [widget] statement to be 
		on the safe side.
		
		Otherwise, you WILL suffer memory leaks in your program.
		
		Adding a __del__ method will not work."""

	# All three calls are Vital.  
	# Do not add a __del__ method: this will prevent the gc from doing its stuff.  Unfortunate, but true.
		for x in self.__widgets: x.destroy() 
		self.__widgets=None
		self.__widgets=()
		#gc.collect()

		if self.curses_pad is not None: 
			self.curses_pad.erase()
			self.refresh()
		self.curses_pad = None
		gc.collect()

	
def mainloop(scr):
	x = True
	while x ==True:
		F = Form()
		F.help = """
Start
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
About half way
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Some text. Some helpful text. !
Ends
"""

		t1 = F.add_widget(tf.TitleText, name="Testing")
		t2 = F.add_widget(tf.TitleText, name="Testing 2")
		m = F.add_widget(sd.TitleSlider, value = 4, out_of=10, name="Slider!")	
		m2= F.add_widget(sd.TitleSlider, value = 4, out_of=10, name="Slider2")
		m3= F.add_widget(sd.TitleSlider, value = 1, out_of=10, name="Slider3")
		j = F.add_widget(sl.DisplayLines, values=("test1", "test2"), name="Testing")
		#m1 = F.add_widget(sl.DisplayLines, values=("test1", "test2", "test3"), max_height=2, max_width=3)
		F.display()
		F.edit()
		F.display
		#x = False
		F.destroy()
	
if __name__ == "__main__":
	import curses.wrapper
	import curses
	import textfield as tf
	import button as bt
	import select as sl
	import slider as sd
	
	print curses.wrapper(mainloop)
	
	
