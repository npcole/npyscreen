#!/usr/bin/python

import pstats
import widget
import profile

p1 = profile.run('widget.test()')

print p1
