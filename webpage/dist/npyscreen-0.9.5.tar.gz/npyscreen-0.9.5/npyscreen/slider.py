#!/usr/bin/python

import curses
import curses.wrapper
import gc

import widget
import screen_area
import textfield
import pmfuncs

class Slider(widget.Widget):

	def __init__(self, screen, value=0, out_of=100, step=1, **keywords):

		self.out_of = out_of
		
		try:
			self.value
		except:
			self.value = value
		
		self.step = step
		
		super(Slider, self).__init__(screen, value=value, **keywords)

	def destroy(self):
		self.textfield = None

	def set_value(self, val):
		#"We can only represent ints or floats, and must be less than what we are out of..."
		if not isinstance(val, int) and not isinstance(val, float):
			raise ValueError

		else:
			self.__value = val

		if self.__value > self.out_of: raise ValueError

	def get_value(self):
		return float(self.__value)

	def update(self):
		self.textfield.erase()
		# can't use background property to set the checkered background, becuase of the last box problem.
		# so the following would not work.
		#if self.editing: self.textfield.bkgd(curses.ACS_HLINE, curses.A_BOLD)
		#else: self.textfield.bkgd(curses.ACS_CKBOARD, curses.A_NORMAL)

		length_of_display = self.textfield.getmaxyx()[1]

		# Can't use all of this. Last char in any window can't be written to on some systems.
		
		blocks_on_screen = length_of_display - 1

		blocks_to_fill = (float(self.value) / float(self.out_of)) * int(blocks_on_screen)
	
		if self.editing:
			self.textfield.attron(curses.A_BOLD)
			self.textfield.bkgd(curses.ACS_HLINE)
		else:
			self.textfield.attroff(curses.A_BOLD)
			self.textfield.bkgd(curses.A_NORMAL)
		
	
		for n in xrange(blocks_on_screen):
			#if self.editing: self.textfield.addch(0,n,curses.ACS_CKBOARD, curses.A_NORMAL)
			#else:            self.textfield.addch(0,n,curses.ACS_CKBOARD, curses.A_NORMAL)
			
			self.textfield.addch(0,n,curses.ACS_CKBOARD, curses.A_NORMAL)	
			
			#self.textfield.addch(0,n,curses.ACS_HLINE, curses.A_NORMAL)	
			#self.textfield.addch(0,n,curses.ACS_SSSS, curses.A_NORMAL)	
	
		for n in xrange(int(blocks_to_fill)):
			self.textfield.addstr(0,n, ' ', curses.A_STANDOUT) #curses.ACS_BLOCK)

		#self.parent.refresh()

	value = property(get_value, set_value)

	def calculate_area_needed(self):
		y,x = self.textfield.getmaxyx()
		return y+self.rely, x+self.relx

	def set_up_handlers(self):
		super(widget.Widget, self).set_up_handlers()
		
		self.handlers.update({ 
					curses.KEY_LEFT: self.h_decrease,
					curses.KEY_RIGHT: self.h_increase,
					ord('+'): self.h_increase,
					ord('-'): self.h_decrease,
					ord('h'): self.h_decrease,
					ord('l'): self.h_increase,
				})

	def h_increase(self, ch):
		if (self.value + self.step <= self.out_of): self.value += self.step

	def h_decrease(self, ch):
		if (self.value - self.step >= 0): self.value -= self.step

	def create_subwindows(self):
		maximum_possible = self.space_available()[1]
		
		if self.request_width:
			if self.request_width > maximum_possible: ask_for = maximum_possible
			else: ask_for = self.request_width
		else:
			ask_for = maximum_possible
			
		self.textfield = self.parent.curses_pad.derwin(1, ask_for, self.rely, self.relx)

class TitleSlider(Slider):
	
	def destroy(self):
		self.label.destroy()
		self.label=None
		self.textfield=None
		self.parent=None
		gc.collect()

	def create_subwindows(self):
		
		maximum_possible = self.space_available()[1]
		
		if self.request_width:
			if self.request_width > maximum_possible: ask_for = maximum_possible
			else: ask_for = self.request_width
		else:
			ask_for = maximum_possible

		_label_area = self.parent.derwin(1, ask_for, self.rely, self.relx)
		
		self.label = textfield.Textfield(_label_area, editable=False, value="")
		

		self.textfield = self.parent.curses_pad.derwin(1, ask_for, self.rely+1, self.relx)

	def update(self):
		
		self.label.value = "%s (%s)" %( self.name, self.translate_value() )
		if self.editing:
			self.label.show_bold=True
		else: 
			self.label.show_bold=False

		self.label.display()
		
		super(TitleSlider, self).update()
	
	def display(self):
		self.label.display()
		self.update()
		self.parent.refresh()

	def calculate_area_needed(self):
		y, x = self.textfield.getmaxyx()
		y += 1 + self.rely
		return y, x

	def translate_value(self):
		"""What do different values mean?  If you subclass this object, and override this 
		method, you can change how the labels are displayed.  This method should return a
		string, to be displayed to the user"""
		
		return "%s / %s" %(self.value, self.out_of)
		
		

	
def mainloop(scr):

	import screen_area as sa

	s = sa.ScreenArea()

	slider = TitleSlider(s, rely=10, relx=2, value=0, step=5, name="Slider 1") #out_of=100)
	slider.display()

	for n in range(101):
		slider.value=n
		slider.display()
		curses.napms(10)

	curses.napms(500)

	slider.value = 0
	slider.display()

	slider.edit()
	slider.display()

if __name__ == "__main__":
	curses.wrapper(mainloop)
