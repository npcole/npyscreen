#!/usr/bin/python

import curses
import curses.ascii
import curses.wrapper
import widget


class CheckBox(widget.Widget):
	
	def __init__(self, screen, name=None, **keywords):
		
		try:
			self.name
		except:
			self.name=name or "Toggle"

		super(CheckBox, self).__init__(screen, name=name, **keywords)
	
	def destroy(self):
		self.lab_and_box = None
		self.parent = None
	
	def calculate_area_needed(self):
		return 1, len(self.name)+7

	def create_subwindows(self):
		
		_my, _mx = self.calculate_area_needed()
		
		self.lab_and_box = self.parent.curses_pad.derwin(_my, _mx, self.rely, self.relx)

	def update(self):
		self.lab_and_box.erase()
		self.lab_and_box.bkgd(' ',curses.A_NORMAL)
	
		if self.editing: self.lab_and_box.attron(curses.A_BOLD)
		else: self.lab_and_box.attroff(curses.A_BOLD)
		
		self.lab_and_box.addstr(0,0, self.name)

		self.lab_and_box.attroff(curses.A_BOLD)

		self.lab_and_box.addstr(0, len(self.name)+3, "[ ]")

		if self.editing: self.lab_and_box.bkgdset(' ',curses.A_STANDOUT)

		if self.value: self.lab_and_box.addstr(0, len(self.name)+4, 'X')
		else: self.lab_and_box.addstr(0, len(self.name)+4, ' ')

		#super(CheckBox, self).display()

	def set_up_handlers(self):
		super(widget.Widget, self).set_up_handlers()
		
		self.handlers.update({
				curses.ascii.SP: self.h_toggle,
				ord('x'):	 self.h_toggle,
				curses.ascii.NL: self.h_select_exit,
			})
	
	def h_toggle(self, ch):
		if self.value is False or self.value is None or self.value == 0: 
			self.value = True
		else: 
			self.value = False
	
	def h_select_exit(self, ch):
		self.value = True
		self.editing = False
		self.how_exited = widget.EXITED_DOWN

class Button(CheckBox):

	def calculate_area_needed(self):

		_height = 3
		_width = False

		if len(self.name)+6 > self.request_width:
			_width = len(self.name)+6
		else: _width = self.request_width

		return _height, _width
	
	def destroy(self):
		self.inner = None
		self.outer = None
		self.parent = None

	def create_subwindows(self):
		
		_my, _mx = self.calculate_area_needed()
		
		self.outer = self.parent.derwin(_my, _mx, self.rely, self.relx)
		self.inner = self.parent.derwin(1, _mx-4, self.rely+1,self.relx+2)

	def update(self):
		
		_on_icon = curses.ACS_CKBOARD
		#_on_icon = curses.ACS_DIAMOND
		
		if len(self.name) > self.inner.curses_pad.getmaxyx()[1]:
			#Then something screwy is going on.  Resize the windows
			self.outer.curses_pad.erase()
			self.create_subwindows()

		if self.value and self.editing:
			#self.inner.bkgd(' ', curses.A_BOLD|curses.A_STANDOUT)
			#self.outer.curses_pad.bkgd(' ', curses.A_BOLD|curses.A_STANDOUT)
			
			self.inner.curses_pad.bkgd(' ', curses.A_STANDOUT)
			self.outer.curses_pad.bkgd(_on_icon, curses.A_STANDOUT)

		elif self.value and not self.editing:
			#self.inner.bkgd(' ', curses.A_DIM|curses.A_STANDOUT)
			#self.outer.curses_pad.bkgd(' ', curses.A_DIM|curses.A_STANDOUT)
			
			self.inner.curses_pad.bkgd(' ', curses.A_NORMAL)
			self.outer.curses_pad.bkgd(_on_icon, curses.A_NORMAL)

		elif not self.value and self.editing:
			self.inner.curses_pad.bkgd(' ', curses.A_STANDOUT)
			self.outer.curses_pad.bkgd(' ', curses.A_STANDOUT)

		elif not self.value and not self.editing:
			self.inner.curses_pad.bkgd(' ', curses.A_NORMAL)
			self.outer.curses_pad.bkgd(' ', curses.A_NORMAL)

		
		self.inner.curses_pad.erase()
		self.outer.curses_pad.box()
	
		if len(self.name) > self.inner.curses_pad.getmaxyx()[1]:
			#Then something screwy is going on. 
			self.create_subwindows()

		#centre the name in the button
		_begin_str_at = ((self.inner.curses_pad.getmaxyx()[1]//2) - (len(self.name)//2))
	
		self.inner.curses_pad.addstr(0,_begin_str_at, self.name[:self.inner.curses_pad.getmaxyx()[1]-2])

		#super(CheckBox, self).display()

def mainloop(scr):

	import screen_area as sa

	p = sa.ScreenArea()
	#c = CheckBox(p)
	c = Button(p, rely=3, name='Testing')
	c.display()


	c.edit()



if __name__ == '__main__':
	
	curses.wrapper(mainloop)

	
