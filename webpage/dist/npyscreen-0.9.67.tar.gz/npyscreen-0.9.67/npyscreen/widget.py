#!/usr/bin/python


import curses
import curses.ascii
import curses.wrapper
import weakref


EXITED_DOWN = 1
EXITED_UP   = -1
EXITED_ESCAPE = 127

class InputHandler(object):
	"An object that can handle user input"

	def handle_input(self, input):
		"""Returns True if input has been dealt with, and no further action needs taking.
		First attempts to look up a method in self.input_handers (which is a dictionary), then
		runs the methods in self.complex_handlers (if any), which is an array of form (test_func, dispatch_func).
		If test_func(input) returns true, then dispatch_func(input) is called. Check to see if parent can handle.
		No further action taken after that point."""
		
		if self.handlers.has_key(input):
			self.handlers[input](input)
			return True

		elif self.handlers.has_key(curses.ascii.unctrl(input)):
			self.handlers[curses.ascii.unctrl(input)](input)
			return True


		else:
			if not hasattr(self, 'complex_handlers'): return False
			for test, handler in self.complex_handlers:
				if test(input): 
					handler(input)
					return True
		try:
			if self.parent.handle_input(input):
				return True

		except AttributeError:
			pass

	# If we've got here, all else has failed, so:
		return False

	def set_up_handlers(self):
		#called in __init__
		self.handlers = {curses.ascii.NL:  self.h_exit_down,
	                       curses.ascii.CR:  self.h_exit_down,
			       curses.ascii.TAB: self.h_exit_down,
			       curses.KEY_DOWN:  self.h_exit_down,
			       curses.KEY_UP:    self.h_exit_up,
			       curses.KEY_LEFT:  self.h_exit_up,
			       curses.KEY_RIGHT: self.h_exit_down,
			       }

		self.complex_handlers = []

###########################################################################################
# Handler Methods here - npc convention - prefix with h_

	def h_exit_down(self, input):
		self.editing = False
		self.how_exited = EXITED_DOWN

	def h_exit_up(self, input):
		self.editing = False
		self.how_exited = EXITED_UP

	

class Widget(InputHandler):
	"A base class for widgets. Do not use directly"

	def destroy(self):
		"""Destroy the widget: methods should provide a mechanism to destroy any references that might
		case a memory leak.  See select. module for an example"""
		pass

	def __init__(self, screen, 
			relx=0, rely=0, name=None, value=None, 
			request_width = False, request_height = False,
			max_height = False, max_width=False,
			editable=True,
			**keywords):
		
		self.parent = screen
		self.relx = relx
		self.rely = rely
		
		self.set_up_handlers()
		
		# To allow derived classes to set this and then call this method safely...
		try:
			self.value
		except AttributeError:
			self.value = value

		# same again
		try:
			self.name
		except:
			self.name=name
			
		self.request_width = request_width 	# widgets should honour if possible
		self.request_height = request_height	# widgets should honour if possible

		self.max_height = max_height
		self.max_width = max_width

		#self.areas = [] # Append subwindows here.

		self.create_subwindows()

		self.editing = False		# Change to true during an edit
		
		self.editable = editable
	
	def create_subwindows(self):
		pass


	def space_available(self):
		y, x = self.parent.curses_pad.getmaxyx()
		return y-self.rely-1, x-self.relx-1

	def calculate_area_needed(self):
		"Classes should provide a function to calculate the screen area they need, returning either y,x, or 0,0 if they want all the screen they can"

		return 0,0
	
	def update(self):
		"""How should object display itself on the screen. Define here, but do not actually refresh the curses
		display, since this should be done as little as possible.  This base widget puts nothing on screen."""
		pass

	def display(self):
		"""Do an update of the object AND refresh the screen"""
		self.update()
		self.parent.refresh()

	def set_editable(self, value):
		if value: self._is_editable = True
		else: self._is_editable = False

	def get_editable(self):
		return(self._is_editable)

	def edit(self):
		self.editing = 1
		self.highlight = 1
		old_value = self.value
		self.how_exited = False
		
		while self.editing:
			self.display()
			self.get_and_use_key_press()

		self.update()

	def get_and_use_key_press(self):
			curses.meta(1)
			self.parent.curses_pad.keypad(1)
			ch = self.parent.curses_pad.getch()
			
			# handle escape-prefixed rubbish.
			if ch == curses.ascii.ESC:
				#self.parent.curses_pad.timeout(1)
				self.parent.curses_pad.nodelay(1)
				ch2 = self.parent.curses_pad.getch()
				if ch2 != -1: 
					ch = curses.ascii.alt(ch2)
				self.parent.curses_pad.timeout(-1) # back to blocking mode
				#curses.flushinp()
			
			self.handle_input(ch)

	def safe_string(self, string):
		"""Check that what you are trying to display contains only
		printable chars.  (Try to catch dodgy input).  Give it a string,
		and it will return a string safe to print - without touching
		the original"""
		if string == None: return ""
		else:
			rtn = filter(self.safe_filter, string)
			return rtn
	
	def safe_filter(self, char):
		if curses.ascii.isprint(char) is True:
			return char
		else: return None

	
		
##########################################################################################
# Python property methods cannot be overridden easily. Though could do it with metaclasses.
# However, simplest thing is for a new class to redefine get_value and set_value, and then 
# have a new property statement of their own.  I don't like it, though....

# For the moment, manage without anything like that.

#	def get_value(self):
#		return(self.__value)
#
#	def set_value(self, vlu):
#		self.__value = vlu
#	value = property(get_value, set_value)

	editable = property(get_editable, set_editable)

def simpletest(scr):
	import screen_area as sa
	a = sa.ScreenArea()
	b = Widget(a)

def mainloop(scr):
	curses.initscr()
	import screen_area as sa
	import textfield as tf
	import button as bt
	import slider as sd
	import select as st
	A = sa.ScreenArea()
	counter = 0
	for x in xrange(100):
		#t = tf.Textfield(A)
		t = bt.Button(A)
		#t = sd.Slider(A)
		#t=sa.ScreenArea()
		
		#t = st.DisplayLines(A, values=("test1", "test2"))
		#t = A.derwin(10,10,10,10)

		# Memory Leak
		#t.edit()

		del t

	for x in range(500):
		pass
	#	curses.napms(100)

def test():
	import curses.wrapper
	curses.wrapper(mainloop)

if __name__ == "__main__":
	curses.wrapper(simpletest)
