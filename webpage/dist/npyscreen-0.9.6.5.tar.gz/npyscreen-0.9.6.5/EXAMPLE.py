#!/usr/bin/python

import npyscreen

def mainloop(scr):

	F = npyscreen.Form(name="Welcome", help=HELPTEXT)
	
	n = F.add_widget(npyscreen.TitleText, name="Name:")
	f = F.add_widget(npyscreen.TitleFileName, name="File:")
	cb= F.add_widget(npyscreen.TitleCombo, name="Combo:", value=None, values=("test","test2","test3"))
	s = F.add_widget(npyscreen.TitleSlider, name="Slider:", value=0, out_of=10, rely=6)
	c = F.add_widget(npyscreen.CheckBox, name="Select me:", rely=9, relx=5)
	m = F.add_widget(npyscreen.MultiSelect, scroll_exit=True, rely = 11, request_height=4)
	m.values = ["Test1", "Test2", "Test3", "Test4", "Test5", "Test6", "Test7"]
	d = F.add_widget(npyscreen.DisplayLines, scroll_exit=True, rely = 16, request_height=4)
	d.values = ["Select this line", "Or this one"]
	#b = F.add_widget(npyscreen.Button, name="A Button", rely = 20, relx = 10)
	b = F.add_widget(npyscreen.MultiLineText, name="Notes", rely=20, relx = 10)
	F.edit()
		
	myvalues = (n.value, f.value, s.value, c.value, b.value)
	
	return myvalues
	


HELPTEXT=file("npyscreen/CHANGELOG").readlines()

if __name__ == "__main__":
	print npyscreen.wrapper(mainloop)
