#!/usr/bin/python
import widget
import textfield
import button
import curses
import curses.ascii
import curses.wrapper
import gc
import Screen

MORE_LABEL = "- more -" # (string to tell user there are more options

class DisplayLines(widget.Widget):
	"""Use all available screen area to show a display of lines"""
	
	def __init__(self, screen, values=None, slow_scroll=False, scroll_exit=False, value=None, **keywords):
		
		self.value = value
	
		self.slow_scroll = slow_scroll

		self.scroll_exit = scroll_exit

		#override - it looks nicer.
		if self.scroll_exit: self.slow_scroll=True
	
		try:
			self.values
		except:
			self.values = values or []

		self.start_display_at = 0
		self.cursor_line = 0

		super(DisplayLines, self).__init__(screen, **keywords)
	
	def create_subwindows(self):
		#max_possibley, max_possiblex = self.parent.curses_pad.getmaxyx()
		max_possibley, max_possiblex = self.space_available()
		
		#max_possibley -= self.rely
		#max_possiblex -= self.relx
		
		if self.request_height == 0 or self.request_height > max_possibley: 
			gety = max_possibley
			if self.max_height and gety > self.max_height:
				gety=self.max_height
		else:
			gety = self.request_height
		
		if self.request_width == 0 or self.request_width > max_possiblex: 
			getx = max_possiblex
			if self.max_width and getx > self.max_width:
				getx=self.max_width
		else:
			getx = self.request_width
		
		# memory leak here?
		# Confirmed.  This causes a subtle memory leak. (18 in 20 objects not removed.)
		# Avoid by using the self.parent instead.
		#self.area = self.parent.derwin(gety, getx, self.rely, self.relx)

		self.display_lines = []
		for line in xrange(gety):
			self.display_lines.append(textfield.Textfield(self.parent, request_width=getx, \
									rely=line+self.rely, relx=self.relx))

	def calculate_area_needed(self):
		return len(self.display_lines)+1, self.display_lines[-1].textfield.getmaxyx()[1]
	
	def update(self):
		#we look this up a lot. Let's have it here.
		display_length = len(self.display_lines)
	
		if self.editing:
			if self.cursor_line < 0: self.cursor_line = 0
			if self.cursor_line > len(self.values)-1: self.cursor_line = len(self.values)-1
			
			if self.slow_scroll:
				if self.cursor_line > self.start_display_at+display_length-1:
					self.start_display_at = self.cursor_line - (display_length-1) 

				if self.cursor_line < self.start_display_at:
					self.start_display_at = self.cursor_line
			
			else:
				if self.cursor_line > self.start_display_at+(display_length-1):
					self.start_display_at = self.cursor_line

				if self.cursor_line < self.start_display_at:
					self.start_display_at = self.cursor_line - (display_length-1)
					if self.start_display_at < 0: self.start_display_at=0

		indexer = 0 + self.start_display_at
		for line in self.display_lines[:-1]: 
			self._print_line(line, indexer)
			indexer += 1
		
		# Now do the final line
		line = self.display_lines[-1]
			
		if len(self.values) <= indexer+1:
			self._print_line(line, indexer)
		else:
			line.value = MORE_LABEL
			line.highlight = False
			line.show_bold = False
		
		if self.editing: 
			self.display_lines[(self.cursor_line-self.start_display_at)].highlight=True

		for x in xrange(len(self.display_lines)): 
			# call update to avoid needless refreshes
			self.display_lines[x].update()

		#Prob don't need this	
		#super(DisplayLines, self).display()

	def _print_line(self, line, value_indexer):
			try:
				line.value = self.values[value_indexer]
			except IndexError:
				line.value = None
		
			if (value_indexer == self.value) and \
				(self.value is not None):
				line.show_bold=True
			else: line.show_bold=False
		
			line.highlight=False

	def set_up_handlers(self):
		self.handlers = {
					curses.KEY_UP:		self.h_cursor_line_up,
					curses.KEY_LEFT:	self.h_cursor_line_up,
					curses.KEY_DOWN:	self.h_cursor_line_down,
					curses.KEY_RIGHT:	self.h_cursor_line_down,
					curses.KEY_NPAGE:	self.h_cursor_page_down,
					curses.KEY_PPAGE:	self.h_cursor_page_up,
					curses.ascii.TAB:	self.h_exit_down,
					curses.ascii.NL:	self.h_select_exit,
					curses.KEY_HOME:	self.h_cursor_beginning,
					curses.KEY_END:		self.h_cursor_end,
					ord('x'):		self.h_select,
					curses.ascii.SP:	self.h_select,
					curses.ascii.ESC:	self.h_exit,
				}

		self.complex_handlers = [
					(self.t_input_isprint, self.h_find_char)
					]
	
	def h_find_char(self, input):
		# The following ought to work, but there is a curses keyname bug
		# searchingfor = curses.keyname(input).upper()
		# do this instead:
		searchingfor = chr(input).upper()
		for counter in xrange(len(self.values)):
			if self.values[counter].find(searchingfor) is not -1:
				self.cursor_line = counter
				break

	def t_input_isprint(self, input):
		if curses.ascii.isprint(input): return True
		else: return False
	
	
	def h_cursor_beginning(self, ch):
		self.cursor_line = 0
	
	def h_cursor_end(self, ch):
		self.cursor_line= len(self.values)

	def h_cursor_page_down(self, ch):
		self.cursor_line += (len(self.display_lines)-1) # -1 because of the -more-
		self.start_display_at += (len(self.display_lines)-1)
		if self.start_display_at > len(self.values) - (len(self.display_lines)-1):
			self.start_display_at = len(self.values) - (len(self.display_lines)-1)
	
	def h_cursor_page_up(self, ch):
		self.cursor_line -= (len(self.display_lines)-1)
		self.start_display_at -= (len(self.display_lines)-1)
		if self.start_display_at < 0: self.start_display_at = 0
					
	def h_cursor_line_up(self, ch):
		self.cursor_line -= 1
		if self.cursor_line < 0 and self.scroll_exit:
			self.h_exit_up(ch)

	def h_cursor_line_down(self, ch):
		self.cursor_line += 1
		try:
			if self.display_lines[self.cursor_line-self.start_display_at].value == MORE_LABEL: 
				if self.slow_scroll:
					self.start_display_at += 1
				else:
					self.start_display_at = self.cursor_line
		except:
			pass
		
		if self.cursor_line >= len(self.values) and self.scroll_exit:
			self.h_exit_down(ch)
	
	def h_exit(self, ch):
		self.editing = False
		self.how_exited = True
	
	def h_select(self, ch):
		self.value = self.cursor_line

	def h_select_exit(self, ch):
		self.value = self.cursor_line
		self.editing = False
		self.how_exited=True

	def edit(self):
		self.editing = True
		self.how_exited = None
		#if self.value: self.cursor_line = self.value
		self.display()
		while self.editing:
			self.get_and_use_key_press()
			self.display()

	def destroy(self):
	###########################################################################
	# The following works.  But only if this object does not have a del method,
	# and only if the gc.collect() call works.
	# you should then call del [widget] explicitly.
		self.display_lines = None
		self.parent = None
		gc.collect()

class MultiSelect(DisplayLines):
	def update(self):
		# Make sure that self.value is a list
		if not hasattr(self.value, "append"):
			if self.value is not None:
				self.value = [self.value, ]
			else:
				self.value = []
		
		super(MultiSelect, self).update()
		
#		#we look this up a lot. Let's have it here.
#		display_length = len(self.display_lines)
#	
#		if self.editing:
#			if self.cursor_line < 0: self.cursor_line = 0
#			if self.cursor_line > len(self.values)-1: self.cursor_line = len(self.values)-1
#			
#			if self.slow_scroll:
#				if self.cursor_line > self.start_display_at+display_length-1:
#					self.start_display_at = self.cursor_line - (display_length-1) 
#
#				if self.cursor_line < self.start_display_at:
#					self.start_display_at = self.cursor_line
#			
#			else:
#				if self.cursor_line > self.start_display_at+(display_length-1):
#					self.start_display_at = self.cursor_line
#
#				if self.cursor_line < self.start_display_at:
#					self.start_display_at = self.cursor_line - (display_length-1)
#					if self.start_display_at < 0: self.start_display_at=0
#	
#		indexer = 0 + self.start_display_at
#		for line in self.display_lines:
#			self._print_line(line, indexer)
#			indexer += 1
#		
#		if self.editing: 
#			self.display_lines[(self.cursor_line-self.start_display_at)].highlight=True
#
#		for x in xrange(len(self.display_lines)): 
#			self.display_lines[x].update()

	def _print_line(self, line, value_indexer):
			try:
				line.value = self.values[value_indexer]
				if (value_indexer in self.value) and \
					(self.value is not None):
					line.show_bold=True
					line.value = "[X] %s" % self.values[value_indexer]
				else: 
					line.show_bold=False
					line.value = "[ ] %s" % self.values[value_indexer]
			except IndexError:
				line.value = None
			
			line.highlight=False
		
	
	def set_up_handlers(self):
		super(MultiSelect, self).set_up_handlers()
		self.handlers.update({
					ord("x"):	 self.h_select_toggle,
					curses.ascii.SP: self.h_select_toggle,
					ord("X"):	 self.h_select,
					"^U":		 self.h_select_none,
				})
	
	def h_select_none(self, input):
		self.value = []
	
	def h_select_toggle(self, input):
		if self.cursor_line in self.value:
			self.value.remove(self.cursor_line)
		else:
			self.value.append(self.cursor_line)
	
	def h_select_exit(self, ch):
		if not self.cursor_line in self.value:
			self.value.append(self.cursor_line)
		self.editing = False
		self.how_exited=True
			

class ScrollLines(DisplayLines):
	
	def edit(self):
		# Make sure a value never gets set.
		value = self.value
		super(DisplayLines, self).edit()
		self.value = value
	
	def h_scroll_line_up(self, input):
		self.start_display_at -= 1

	def h_scroll_line_down(self, input):
		self.start_display_at += 1	

	def h_scroll_page_down(self, input):
		self.start_display_at += len(self.display_lines)

	def h_scroll_page_up(self, input):
		self.start_display_at -= len(self.display_lines)

	def h_show_beginning(self, input):
		self.start_display_at = 0	
	
	def h_show_end(self, input):
		self.start_display_at = len(self.values) - len(self.display_lines)
	
	def h_select_exit(self, input):
		self.exit(self, input)
	
	def set_up_handlers(self):
		super(ScrollLines, self).set_up_handlers()
		self.handlers = {
					curses.KEY_UP:		self.h_scroll_line_up,
					curses.KEY_LEFT:	self.h_scroll_line_up,
					curses.KEY_DOWN:	self.h_scroll_line_down,
					curses.KEY_RIGHT:	self.h_scroll_line_down,
					curses.KEY_NPAGE:	self.h_scroll_page_down,
					curses.KEY_PPAGE:	self.h_scroll_page_up,
					curses.KEY_HOME:	self.h_show_beginning,
					curses.KEY_END:		self.h_show_end,
					curses.ascii.NL:	self.h_exit,
					curses.ascii.SP:	self.h_exit,
					ord('x'):		self.h_exit,
					ord('q'):		self.h_exit,
					curses.ascii.ESC:	self.h_exit,
				}

		self.complex_handlers = [
					]
	def update(self):
		#we look this up a lot. Let's have it here.
		display_length = len(self.display_lines)
	
		if self.start_display_at > len(self.values) - display_length: 
			self.start_display_at = len(self.values) - display_length
		if self.start_display_at < 0: self.start_display_at = 0
		
		indexer = 0 + self.start_display_at
		for line in self.display_lines[:-1]: 
			self._print_line(line, indexer)
			indexer += 1
		
		# Now do the final line
		line = self.display_lines[-1]
			
		if len(self.values) <= indexer+1:
			self._print_line(line, indexer)
		else:
			line.value = MORE_LABEL
			line.highlight = False
			line.show_bold = False
		
		for x in xrange(len(self.display_lines)): 
			# call update to avoid needless refreshes
			self.display_lines[x].update()


def ViewText(display_me, name=None):
	V = Screen.Form(name=name, framed=True)

	try:
		display_me_lines = display_me.split("\n")
	except AttributeError:
		display_me_lines = [x.rstrip().replace('\t', ' '*4)  for x in display_me]
	
	vr = V.add_widget(ScrollLines, values = display_me_lines)
	V.display()
	vr.edit()

	
def MakeChoice(choices, name=None, initial_value=None):
	C = Screen.Form(name=name, framed=True)
	
	sel = C.add_widget(DisplayLines, values=values, value=initial_value)
	C.display()
	sel.edit()
	return sel.value

def MakeMultiChoice(choices, name=None, initial_value=None):
	C = Screen.Form(name=name, framed=True)
	
	sel = C.add_widget(MultiSelect, values=choices, value=initial_value)
	C.display()
	sel.edit()
	return sel.value

def memtest(scr):
	import screen_area as sa
	a = sa.ScreenArea()
	
	while 1:
		b = MultiSelect(a,)
		b.destroy()
		del b

def mainloop(scr):
	import screen_area as sa
	a = sa.ScreenArea()

	sl = ScrollLines(a,)
	
	for l in range(290): sl.values.append("testing %s" %l)
	sl.value=20
	sl.cursor_line=4
	sl.display()
	sl.edit()
	
	curses.napms(2000)
	
	return dir(sl)

def multitest(scr):
	import Screen
	choices = ("one", "two", "five")
	choice = MakeMultiChoice(choices)
	return choice


if __name__ == "__main__":
	print curses.wrapper(multitest)
