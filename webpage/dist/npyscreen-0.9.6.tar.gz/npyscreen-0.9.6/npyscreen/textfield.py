#!/usr/bin/python

import curses
import curses.ascii
import curses.panel
import curses.wrapper

import gc
import widget
import pmfuncs
import weakref
import select
import Screen

class Textfield(widget.Widget):
	def __init__(self, screen, value=None, **keywords):
		try:
			self.value
		except:
			self.value = value or ""
		
		super(Textfield, self).__init__(screen, **keywords)

		self.cursor_position = None
		self.display_from = None
		
		self.show_bold = False
		self.highlight = False
		
		# We want our value to be of string type. Could do sanity 
		# check, but probably not needed.
		self.begin_at = 0

		self.update()

	def destroy(self):
		self.textfield = None
		self.parent=None

	def create_subwindows(self):
		maximum_possible = self.space_available()[1]
		
		if self.request_width:
			if self.request_width > maximum_possible: ask_for = maximum_possible
			else: ask_for = self.request_width
		else:
			# pick a sensible size.
			#if maximum_possible < 40: ask_for = maximum_possible
			#else: ask_for = 40
			
			#Get everything
			ask_for = maximum_possible
			
		self.textfield = self.parent.curses_pad.derwin(1, ask_for, self.rely, self.relx)
		self.maximum_string_length = (self.textfield.getmaxyx()[1] -1 - 1)  # leave blank space at the end to show cursor.

	def update(self):
		"""Update the contents of the textbox, without calling the final refresh to the screen"""
		# cursor not working. See later for a fake cursor
		#if self.editing: pmfuncs.show_cursor()
		#else: pmfuncs.hide_cursor()
		
		# Not needed here -- gets called too much!
		#pmfuncs.hide_cursor()

		if self.begin_at < 0: self.begin_at = 0

		self.textfield.erase()
		
		if self.editing:
			if self.cursor_position is False:
				self.cursor_position = len(self.value)

			elif self.cursor_position > len(self.value):
				self.cursor_position = len(self.value)

			elif self.cursor_position < 0:
				self.cursor_position = 0

			if self.cursor_position < self.begin_at:
				self.begin_at = self.cursor_position

			while self.cursor_position > self.begin_at + self.maximum_string_length:
				self.begin_at += 1


		if self.highlight:
			self.textfield.bkgd(' ', curses.A_STANDOUT)
		else: 
			self.textfield.bkgd(' ',curses.A_NORMAL)

		if self.show_bold: 
			self.textfield.attron(curses.A_BOLD)
		else: 
			self.textfield.attron(curses.A_NORMAL)
		self._print()

		
		if self.editing:
			# Cursors do not seem to work on pads.
			#self.parent_screen.move(self.rely, self.cursor_position - self.begin_at)
			# let's have a fake cursor

			_cur_loc_x = self.cursor_position - self.begin_at
			char_under_cur = self.textfield.inch(0, _cur_loc_x)
			self.textfield.addch(0, self.cursor_position - self.begin_at, char_under_cur, curses.A_STANDOUT)

	def _print(self):

		if self.value == None: return

		display_value = self.value.expandtabs()

		problem = False
		for c in display_value: 
			if curses.ascii.isprint(c): pass
			else: problem = True

		if problem: 
			display_value = "*** BINARY DATA ***"

		if self.maximum_string_length < len(str(display_value)):
			self.textfield.addstr(0,0, display_value[self.begin_at:self.maximum_string_length+self.begin_at])

		else:
			self.textfield.addstr(0,0, display_value)

	def edit(self):
		self.editing = 1
		self.cursor_position = len(self.value)
		self.textfield.keypad(1)
		
		old_value = self.value
		
		self.how_exited = False

		while self.editing:
			self.display()
			self.get_and_use_key_press()

		self.begin_at = 0
		self.display()

		return self.how_exited, self.value

	def calculate_area_needed(self):
		y, x = self.textfield.getmaxyx()
		return y+1, x

	def show_brief_message(self, message):
		curses.beep()
		keep_for_a_moment = self.value
		self.value = message
		self.editing=False
		self.display()
		curses.napms(1200)
		self.editing=True
		self.value = keep_for_a_moment
		

	###########################################################################################
	# Handlers and methods

	def set_up_handlers(self):
		super(Textfield, self).set_up_handlers()	
		
		self.handlers.update({curses.KEY_LEFT:    self.h_cursor_left,
	                       curses.KEY_RIGHT:   self.h_cursor_right,
			       curses.KEY_DC:	   self.h_delete_right,
			       curses.ascii.DEL:   self.h_delete_right,
			       curses.ascii.BS:    self.h_delete_left,
			       curses.KEY_BACKSPACE: self.h_delete_left,
			       "^K":		   self.h_erase_right,
			       "^U":		   self.h_erase_left,
			})

		self.complex_handlers.extend((
                                             (self.t_input_isprint, self.h_addch),
		                            # (self.t_is_ck, self.h_erase_right),
					    # (self.t_is_cu, self.h_erase_left),
					    ))

	def t_input_isprint(self, input):
		if curses.ascii.isprint(input): return True
		else: return False

	def h_addch(self, input):
		if self.editable:
			#self.value = self.value[:self.cursor_position] + curses.keyname(input) \
			#	+ self.value[self.cursor_position:]
			#self.cursor_position += len(curses.keyname(input))
			
			# workaround for the metamode bug:
			self.value = self.value[:self.cursor_position] + chr(input) \
				+ self.value[self.cursor_position:]
			self.cursor_position += len(chr(input))

			# or avoid it entirely:
			#self.value = self.value[:self.cursor_position] + curses.ascii.unctrl(input) \
			#	+ self.value[self.cursor_position:]
			#self.cursor_position += len(curses.ascii.unctrl(input))



# Now that the handle input loop checks keynames, these are obsolete.
#	def t_is_ck(self, input):
#		# Use try loop because some 'inputs', such as screen resize, would cause a ValueError
#		try:
#			if curses.keyname(input) == "^K": return True
#		except ValueError:
#			pass
#
#		return False
#
#	def t_is_cu(self, input):
#		# Use try loop because some 'inputs', such as screen resize, would cause a ValueError
#		try:
#			if curses.keyname(input) == "^U": return True
#		except ValueError:
#			pass
#
#		return False

	def h_cursor_left(self, input):
		self.cursor_position -= 1

	def h_cursor_right(self, input):
		self.cursor_position += 1

	def h_delete_left(self, input):
		if self.editable and self.cursor_position > 0:
			self.value = self.value[:self.cursor_position-1] + self.value[self.cursor_position:]
		
		self.cursor_position -= 1
		self.begin_at -= 1

	
	def h_delete_right(self, input):
		if self.editable:
			self.value = self.value[:self.cursor_position] + self.value[self.cursor_position+1:]

	def h_erase_left(self, input):
		if self.editable:
			self.value = self.value[self.cursor_position:]
			self.cursor_position=0
	
	def h_erase_right(self, input):
		if self.editable:
			self.value = self.value[:self.cursor_position]

class PasswordEntry(Textfield):
	def _print(self):
		if self.maximum_string_length < len(self.value):
			tmp_x = 0
			for i in self.value[self.begin_at:self.maximum_string_length+self.begin_at]:
				self.textfield.addch(0, tmp_x, curses.ACS_BULLET)
				tmp_x += 1

		else:
			tmp_x = 0
			for i in self.value:
				self.textfield.addch(0, tmp_x, curses.ACS_BULLET)
				tmp_x += 1

class TitleText(Textfield):

	#Specify the type of field to create (a reference to make subclassing easier) outside of init.  It doesn't need to be stored per-object,
	#and specifiying it in __init__ functions requires a little work to ensure that the parent does not over-right the request of the child.
	_entry_type = Textfield

	def get_value(self):
		try:
			return self.textarea.value
		except:
			try:
				return self.__tmp_value
			except:
				return None
	
	def set_value(self, value):
		try:
			self.textarea.value = value
		except:
			# probably trying to set the value before the textarea is initialised
			self.__tmp_value = value
			
	def del_value(self):
		del self.textarea.value

	value = property(get_value, set_value, del_value)
	
	def __init__(self, screen, 
		begin_entry_at = 10, 
		field_width_request = 30,
		value = None,
		**keywords):

		self.text_field_begin_at = begin_entry_at
		self.field_width_request = field_width_request
		
		super(TitleText, self).__init__(screen, **keywords)
		self.value = value or ""

	def destroy(self):
		self.label_space_win.destroy()
		self.label_space_win=None
		self.textarea.destroy()
		self.textarea = None
		self.parent=None

	#def __getattr__(self, name):
	#	if hasattr(self.textarea, name): return getattr(self.textarea, name)
	#	else: raise AttributeError, %s "has no attribute %s" % (self.__class__, name)

	def create_subwindows(self):
		if self.name != None:
			label_space_needed = len(self.name)+3
		else:
			label_space_needed = 0

		# Try to work out if we want one or two lines of screen.
		self.hint_use_two_lines = False

		self.label_space_win = Textfield(self.parent, rely=self.rely, relx=self.relx,
							request_width = label_space_needed,
							value = self.name,
							editable = False)

		if self.label_space_win.calculate_area_needed()[1] > self.text_field_begin_at:
			self.hint_use_two_lines = True

		if self.space_available < self.label_space_win.calculate_area_needed()[1] + self.field_width_request:
			self.hint_use_two_lines = True

		if self.hint_use_two_lines:
			self.textarea = self.__class__._entry_type(self.parent, name=self.name, rely=self.rely+1, relx = self.text_field_begin_at, value=self.value)
		
		else:
			self.textarea = self.__class__._entry_type(self.parent, name=self.name, rely=self.rely, relx = self.text_field_begin_at, value=self.value)
		
	def update(self):
		if self.editing: self.label_space_win.show_bold=True
		else: self.label_space_win.show_bold=False
		#self.textarea.value=self.value
		self.label_space_win.update()
		self.textarea.update()

	def edit(self):
		self.editing=True
		self.display()
		self.textarea.edit()
		#self.value = self.textarea.value
		self.how_exited = self.textarea.how_exited
		self.editing=False
		self.display()

	def calculate_area_needed(self):
		x_needed_text = self.textarea.calculate_area_needed()[1]

		y_needed_label, x_needed_label = self.label_space_win.calculate_area_needed()

		if x_needed_text > x_needed_label: x_return = x_needed_text
		else: x_return = x_needed_label

		y_return = self.textarea.textfield.getparyx()[0]
		if self.hint_use_two_lines: y_return += 1
		return(y_return+1, x_return+1)

class TitlePassword(TitleText):
	
	_entry_type = PasswordEntry
	
	def __init__(self, screen, **keywords):
		super(TitlePassword, self).__init__(screen, **keywords)

class ComboBox(Textfield):
	def __init__(self, screen, values=None,**keywords):
		super(ComboBox, self).__init__(screen, **keywords)
		self.values = values or []

	def update(self):
		#Same as the textbox stuff, but without a cursor, or worrying about start and end positions of text:
		#We'll alwayws show from the start (see _print)

		self.textfield.erase()

		if self.editing:
			#self.textfield.bkgd(' ', curses.A_STANDOUT)
			self.textfield.attron(curses.A_STANDOUT)
		else: 
			#self.textfield.bkgd(' ',curses.A_NORMAL)
			self.textfield.attroff(curses.A_STANDOUT)

		if self.show_bold: 
			self.textfield.attron(curses.A_BOLD)
		else: 
			self.textfield.attron(curses.A_NORMAL)
		self._print()


	def _print(self):
		if self.value == None:
			self.textfield.addstr(0,0, "-")
		else:
			lengthoffield=self.textfield.getmaxyx()[1] - 1
			try:
				self.textfield.addstr(0,0, self.values[self.value][:lengthoffield])
			except:
				pass

	def edit(self):
		#We'll just use the widget one
		super(Textfield, self).edit()

	def set_up_handlers(self):
		super(Textfield, self).set_up_handlers()

		self.handlers.update({curses.ascii.SP:  self.change_value,
				      curses.ascii.TAB: self.change_value,
				      #curses.ascii.NL:  self.change_value,
				      ord('x'):         self.change_value,
				      })
		

	def change_value(self, input):
		"Pop up a window in which to select the values for the field"

		tmp_window = Screen.Form(name=self.name, framed=True)
		sel = tmp_window.add_widget(select.DisplayLines, values=self.values, value=self.value)
		tmp_window.display()
		sel.edit()
		self.value = sel.value

		tmp_window.destroy()
		del tmp_window
		self.parent.refresh()
		
class TitleCombo(TitleText):
	_entry_type = ComboBox

	def __init__(self, screen, values=None,**keywords):
		self.values = values or []
		#self.value = value
		super(TitleCombo, self).__init__(screen, **keywords)
		#self.textarea.value=self.value
		if self.value == '': self.value = None

	def update(self):
		#self.textarea.value = 0
		self.textarea.values = self.values
		super(TitleCombo, self).update()

class AutoComplete(Textfield):
	"""This class itself is fairly useless, but you can use it as a base class for other things.  The
	filebrowser widgets do.  Should be easy to use in conjunction with a class derived from TitleText"""
	def set_up_handlers(self):
		super(AutoComplete, self).set_up_handlers()
		
		self.handlers.update({curses.ascii.TAB: self.auto_complete})

	def auto_complete(self, input):
		curses.beep()

	def get_choice(self, values):
		# If auto_complete needs the user to select from a list of values, this function lets them do that.
		
		tmp_window = Screen.Form(name=self.name, framed=True)
		sel = tmp_window.add_widget(select.DisplayLines, values=values, value=self.value)
		tmp_window.display()
		sel.value=0
		sel.edit()
		rtn = sel.value

		# using new style Form wrapper so these not needed.
		#tmp_window.destroy()
		#del tmp_window
		self.parent.refresh()

		return sel.value
		
	
def color_test(scr):
	import screen_area as sa
	curses.init_pair(1, curses.COLOR_RED, curses.COLOR_BLUE)	
	#curses.start_color()
	scr.attron(curses.color_pair(1))
	scr.addstr("Hello")
	scr.refresh()
	scr.getch()

def mainloop(scr):

	import screen_area as sa

	curses.start_color()
	scr1 = sa.ScreenArea()
	

	t = TitleText(scr1, name="Textfield1", value = "This is a test. This is a second sentence. This is a third sentence",
					begin_entry_at= 16)
	t.edit()
	a = t.calculate_area_needed()
	#scr.getch()

	p = TitlePassword(scr1, rely=10, begin_entry_at=10, name="Password1")
	p.edit()

	q = TitleCombo(scr1, rely=15, values=['test1','test2','test3'], value=2, name="Combo1")
	q.edit()


	return t.value, p.value, q.value

if __name__ == "__main__":

	print curses.wrapper(color_test)
