#!/usr/bin/python

######################################################################
# This code is currently incomplete. Do not use.
#
#


import widget
import button
import Screen
import select
import filename
import pmfuncs

import os
import os.path
import tempfile

import curses

def StringToEditor(edit_this):
	tmp_filename = tempfile.mkstemp(text=True)[1]

	t = file(tmp_filename, 'w')
	if edit_this: 
		t.write(edit_this)
	t.close()

	editor = find_editor()
	call_editor(editor, tmp_filename)

	tmp = open(tmp_filename)
	rtn = tmp.read()
	tmp.close()


	return rtn
	
def get_editor_name_from_user():
	
	HELPTEXT=\
"""
I am attempting to load an external editor.  I have checked your system
environment variables and you do not seem to have specified a default
editor in them.  

Please enter in the box below the name of the editor you wish to use.

To prevent this message from being shown again, please set one of the
NPYSCREEN_EDITOR, EDITOR or VISUAL environment variables.
"""
	HELPTEXT=HELPTEXT.split("\n")
	F = Screen.Form()
	help = F.add_widget(select.ScrollLines, request_height = 15, values=HELPTEXT)
	fnbox = F.add_widget(filename.TitleFileName, name="Editor:")
	if os.path.exists("/usr/bin/vi"): fnbox.value = "/usr/bin/vi"
	F.display()
	fnbox.edit()
	while not os.path.exists(fnbox.value):
		fnbox.show_brief_message("Program does not exist")
		fnbox.edit()
	return fnbox.value

def find_editor():
	# return the external editor. Try to repect users' choices. Make a sensible guess as to a default.
	for attempt in ('NPYSCREEN_EDITOR', 'EDITOR', 'VISUAL'):
		env =  os.getenv(attempt)
		if env is not None: return env
	
	user_value = get_editor_name_from_user()

	#if os.path.exists("/usr/bin/editor"): return "/usr/bin/editor"

	if user_value: 
		return user_value
	
	# a last-ditch default could go here.
	
	
def call_editor(editor, file_name):
	# This is very unsafe if we don't trust the source for editor and filename.
	# To be very safe, check that "editor" is in the user's path and check that it's location is sensible, before calling this function.

	curses.def_prog_mode()
	curses.endwin()
	
	rtn = os.system("%s %s" % (editor, file_name))
	if rtn is not 0: return False
	else: return True

	curses.reset_prog_mode()

	return rtn
	

class MultiLineText(button.Button):
#	def __init__(self, name=None, *args, **keywords):
#		self.name = "Notes"
#		super(StringToEditor, self).__init__(name=Name, *args, **keywords)
	
	
	def set_up_handlers(self):
		super(widget.Widget, self).set_up_handlers()
		
		self.handlers.update({
				curses.ascii.SP: self.h_edit_contents,
				ord('x'):	 self.h_edit_contents,
				curses.ascii.NL: self.h_edit_contents,
			})

	def h_edit_contents(self, key):
		self.value = StringToEditor(self.value)
		
		#self.parent.refresh()
		#self.parent.display()
		# if you have problems with cursors after calling the
		# external program this is odd, but this seems to cure it
		#pmfuncs.show_cursor() 
		#pmfuncs.hide_cursor()
		#self.parent.curses_pad.redrawwin()

	
def mainloop(scr):
	global text
	import Screen
	A = Screen.Form()
	ml = A.add_widget(MultiLineText, value=text, name="Add Notes")
	#ml.start_display_at=2
	#ml.cursor_position=50
	A.display()
	A.edit()
	A.curses_pad.getch()
	
	return ml.value 

if __name__ == "__main__":
	import curses.wrapper

	text = """This is a load of text.

Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. 

Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. Foo, bar foo, old chap. 
	"""
	
	print curses.wrapper(mainloop)
