#!/usr/bin/python

import curses
import curses.panel
import curses.wrapper

import pmfuncs
import weakref

class SizeError(Exception):
	"Raised if the terminal screen is too small for the application"

class ProgrammingError(Exception):
	"The Programmer has done something silly."

class ScreenArea(object):

	"""Do not use. Class from which frames and popups decend. Note the defaults for minimum screen size (see init) correspond to a standard terminal.
	User can safely resize the screen, but widgets placed within this area (even if hidden) will not cause an error.  It is perfectly fine to set a 
	fixed size area too, using the lines and columns arguments to the __init__ function"""

	def __init__(self, lines=0, columns=0, 
			minimum_lines = 24,
			minimum_columns = 80, **keywords):

		# hide the cursor
		pmfuncs.hide_cursor()
		
	# Putting a default in here will override the system in _create_screen. For testing?

		self.lines = lines #or 25
		self.columns = columns #or 80

		self.min_l = minimum_lines
		self.min_c = minimum_columns


		# Panels can be bigger than the screen area. These two variables
		# set which bit of the panel should be visible.
		# ie. They are about the virtual, not the physical, screen.
		self.show_from_y = 0
		self.show_from_x = 0
		self.show_atx = 0
		self.show_aty = 0
		self.ALL_SHOWN = False

		self._create_screen()

	def _create_screen(self):
	
		try:
			if self.lines_were_auto_set: self.lines = None
			if self.cols_were_auto_set: self.columns = None
		except: pass

		
		if not self.lines: 
			self.lines = self._max_physical()[0]+1
			self.lines_were_auto_set = True
		if not self.columns: 
			self.columns = self._max_physical()[1]+1
			self.cols_were_auto_set = True

		if self.min_l > self.lines:
			self.lines = self.min_l

		if self.min_c > self.columns:
			self.columns = self.min_c

		#self.area = curses.newpad(self.lines, self.columns)
		self.curses_pad = curses.newpad(self.lines, self.columns)

		self.max_y, self.max_x = self.curses_pad.getmaxyx()

	def _max_physical(self):
		"How big is the physical screen?"

		# let's see how big we could be: create a temp screen
		# and see the size curses makes it.  No good to keep, though
		mxy, mxx = curses.newwin(0,0).getmaxyx()

		# return safe values, i.e. slightly smaller.
		return (mxy-1, mxx-1)
	
	def refresh(self):
		pmfuncs.hide_cursor()
		_my, _mx = self._max_physical()
		
		# Since we can have pannels larger than the screen
		# let's allow for scrolling them
		self.curses_pad.refresh(self.show_from_y,self.show_from_x,self.show_aty,self.show_atx,_my,_mx)

		if self.show_from_y is 0 and \
		self.show_from_x is 0 and \
		(_my >= self.lines) and \
		(_mx >= self.columns):
			self.ALL_SHOWN = True

		else:
			self.ALL_SHOWN = False
			
		

		# see if we can put outselves in the middle of the screen
		# The following code works, but causes flicker.
		# better to stick with window in top left.
		#_begx = (_mx // 2) - ( self.columns // 2)
		#_begy = (_my // 2) - (self.lines // 2)
		#_blanker = curses.newwin(0,0)
		#_blanker.erase()
		#_blanker.noutrefresh()
		#self.area.noutrefresh(0,0,_begy,_begx, _my, _mx)
		#curses.doupdate()


	#def rtn_screen_object(self):
	#	return self.area

	#def set_screen_object(self):
	#	# This would make no sense.
	#	raise ProgrammingError

	def derwin(self, lines, cols, rely, relx):
		"""Mimics the derwin call to curses objects, hence the syntax. The subwindow is not remembered or known about by the parent object. Keep hold 
		of it yourself!"""
		
		return SubArea(self, rely, relx, lines=lines, columns=cols)
	
	#def del_screen_object(self):
	#	del(self.area)

	#curses_pad = property(rtn_screen_object, set_screen_object, del_screen_object)

class SubArea(ScreenArea):
	
	def __init__(self, parent, rely, relx, **keywords):

		self.parent = parent
		self.rely = rely
		self.relx = relx
		
		self.show_aty = self.rely
		self.show_atx = self.relx

		super(SubArea, self).__init__(**keywords)
		
		self.rely = rely
		self.relx = relx

		self.show_aty = self.rely
		self.show_atx = self.relx

	def _create_screen(self):
		
		#self.area = self.parent.area.derwin(self.lines, self.columns, self.rely, self.relx)
		self.curses_pad = self.parent.curses_pad.derwin(self.lines, self.columns, self.rely, self.relx)

def mainloop(scr):
	a = ScreenArea(lines=200, columns=200)
	a.refresh()
	a.area.border()
	a.refresh()
	import pmfuncs
	#pmfuncs.hidecursor()
	while 1:
		a.area.syncok(1)
		a.area.getch()
		a.area.move(10,10)
		a.area.leaveok(1)
		a.area.cursyncup()
		a.refresh()
	return a.max_y, a.max_x

def texttest(scr):
	import textfield as nt

	a = ScreenArea()

	t = nt.TitleText(a, rely = 2, title = "T1")
	t2= nt.TitleText(a, rely = 3, title = "T2")
	t3= nt.TitleText(a, rely = 4, title = "T3")
	t.edit()
	t2.edit()
	t3.edit()

	b = ScreenArea()
	b.area.addstr(5,5,"This is over the top")
	b.refresh()
	curses.napms(1000)
	a.refresh()
	curses.napms(1000)

	sub = a.derwin(5,10, 10, 15)

	sub.area.border()

	sub.refresh()

	curses.napms(1000)

def memory_leak_test(scr):

	SA = ScreenArea()
	SA.curses_pad.addstr(2,0, "refs to S: %s" %sys.getrefcount(ScreenArea))
	SA.curses_pad.addstr(3,0, "refs to t: %s" %sys.getrefcount(nt.Textfield))
	SA.refresh()
	for x in xrange(1000):
		"""The following would make a memory leak without the final del(sub)
		a = Screen_Area()
		t = nt.Title_text_field(a, rely = 2, title = "T1")
		sub = a.derwin(5,10,10,15)
		sub.area.border()
		a.refresh()
		del(sub). However, it is entirely fine as a function, as shown"""

		#t=wd.Widget(SA)
		#t = bt.Button(SA)
		#t = bt.CheckBox(SA)
		#t = nt.Textfield(SA)
		global printme 
		#printme = str(gc.get_referrers(nt.Textfield)).split(',')
		#printme = gc.get_referrers(nt.Textfield)
		t = sl.DisplayLines(SA)
		t.destroy()
		SA.curses_pad.addstr(4,0, "refs to S: %s" %sys.getrefcount(ScreenArea))
		SA.curses_pad.addstr(5,0, "refs to t: %s" %sys.getrefcount(nt.Textfield))
		SA.refresh()
		del t
	

	curses.napms(100)
	

if __name__ == "__main__":
	import gc
	import sys
	import textfield as nt
	import widget as wd
	import select as sl
	#import button as bt
	print curses.wrapper(memory_leak_test)
	##for x in printme:
	##	print x
	print gc.get_threshold()
