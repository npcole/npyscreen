DISABLE_ALL_COLORS = False
ASCII_ONLY         = True # See the safe_string function in wgwidget.  At the moment the encoding is not safe