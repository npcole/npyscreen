#!/usr/bin/python
# encoding: utf-8

import sys
import os
import Form
import curses

class Popup(Form.Form):
    def __init__(self, lines = 12, columns=60,
        minimum_lines=None,
        minimum_columns=None,
        *args, **keywords):
        super(Popup, self).__init__(lines = lines, columns=columns, 
                                        minimum_columns=40, minimum_lines=8, *args, **keywords)
        self.show_atx = 10
        self.show_aty = 2
        

def main(*args):
    import titlefield
    import textbox
    import slider
    import multiline
    

    F = Popup(name="Testing")
    w = F.add_widget(titlefield.TitleText)
    str = "useable space = %s, %s; my height and width is: %s, %s" % (F.widget_useable_space()[0], F.widget_useable_space()[1], w.height, w.width)
    w.value = str
    F.nextrely += 1
    s = F.add_widget(slider.Slider, out_of=10)
    F.edit()


if __name__ == '__main__':
    import curses.wrapper
    from Form import *
    curses.wrapper(main)

