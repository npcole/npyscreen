#!/usr/bin/python
import multiline
import checkbox
import curses

class MultiSelect(multiline.MultiLine):
	_contained_widgets = checkbox.Checkbox


	def update(self, clear=True):
		# Make sure that self.value is a list
		if not hasattr(self.value, "append"):
			if self.value is not None:
				self.value = [self.value, ]
			else:
				self.value = []
				
		super(MultiSelect, self).update(clear=clear)

	def _print_line(self, line, value_indexer):
		try:
			line.value = self.values[value_indexer]
			line.hide = False
			if (value_indexer in self.value and (self.value is not None)):
				line.show_bold = True
				line.name = self.values[value_indexer]
				line.value = True
			else:
				line.show_bold = False
				line.name = self.values[value_indexer]
				line.value = False
			
		except IndexError:
			line.name = None
			line.hide = True

		line.highlight= False

	def set_up_handlers(self):
		super(MultiSelect, self).set_up_handlers()
		self.handlers.update({
					ord("x"):	 self.h_select_toggle,
					curses.ascii.SP: self.h_select_toggle,
					ord("X"):	 self.h_select,
					"^U":		 self.h_select_none,
				})
	
	def h_select_none(self, input):
		self.value = []
	
	def h_select_toggle(self, input):
		if self.cursor_line in self.value:
			self.value.remove(self.cursor_line)
		else:
			self.value.append(self.cursor_line)
	
	def h_select_exit(self, ch):
		if not self.cursor_line in self.value:
			self.value.append(self.cursor_line)
		self.editing = False
		self.how_exited=True

class TitleMultiSelect(multiline.TitleMultiLine):
	_entry_type = MultiSelect
			
		
def simpletest(screen):
	import screen_area
	SA = screen_area.ScreenArea()
	w = TitleMultiSelect(SA, name="Title Multi", values = ["line 1", "line 2", "line 3", "line 4", "line 5"], max_height=4)
	w.value = [1, 2]
	w.edit()
	w.update()
	SA.refresh()
	curses.napms(2000)
	

if __name__ == "__main__":
	import curses.wrapper
	curses.wrapper(simpletest)
	print "The circle is now complete"
