#!/usr/bin/env python

import curses
import curses.panel
import curses.wrapper
import pmfuncs

class ScreenArea(object):
	"""A screen area that can be safely resized.  But this is a low-level class,
	object you are looking for."""

	def __init__(self, lines=0, columns=0, 
			minimum_lines = 24,
			minimum_columns = 80, **keywords):

		
	# Putting a default in here will override the system in _create_screen. For testing?

		self.lines = lines #or 25
		self.columns = columns #or 80

		self.min_l = minimum_lines
		self.min_c = minimum_columns

		# Panels can be bigger than the screen area. These two variables
		# set which bit of the panel should be visible.
		# ie. They are about the virtual, not the physical, screen.
		self.show_from_y = 0
		self.show_from_x = 0
		self.show_atx = 0
		self.show_aty = 0
		self.ALL_SHOWN = False

		self._create_screen()

	def _create_screen(self):
	
		try:
			if self.lines_were_auto_set: self.lines = None
			if self.cols_were_auto_set: self.columns = None
		except: pass

		
		if not self.lines: 
			self.lines = self._max_physical()[0]+1
			self.lines_were_auto_set = True
		if not self.columns: 
			self.columns = self._max_physical()[1]+1
			self.cols_were_auto_set = True

		if self.min_l > self.lines:
			self.lines = self.min_l

		if self.min_c > self.columns:
			self.columns = self.min_c

		#self.area = curses.newpad(self.lines, self.columns)
		self.curses_pad = curses.newpad(self.lines, self.columns)

		self.max_y, self.max_x = self.curses_pad.getmaxyx()

	def _max_physical(self):
		"How big is the physical screen?"

		# let's see how big we could be: create a temp screen
		# and see the size curses makes it.  No good to keep, though
		mxy, mxx = curses.newwin(0,0).getmaxyx()

		# return safe values, i.e. slightly smaller.
		return (mxy-1, mxx-1)

	def useable_space(self, rely=0, relx=0):
		mxy, mxx = curses.newwin(0,0).getmaxyx()
		return (mxy-1-rely, mxx-1-relx)
	
	def refresh(self):
		pmfuncs.hide_cursor()
		_my, _mx = self._max_physical()
		self.curses_pad.move(0,0)
		
		# Since we can have pannels larger than the screen
		# let's allow for scrolling them
		self.curses_pad.refresh(self.show_from_y,self.show_from_x,self.show_aty,self.show_atx,_my,_mx)

		if self.show_from_y is 0 and \
		self.show_from_x is 0 and \
		(_my >= self.lines) and \
		(_mx >= self.columns):
			self.ALL_SHOWN = True

		else:
			self.ALL_SHOWN = False
		

def test_loop(screen):
	A = ScreenArea()
	A.refresh()
	
	


if __name__ == '__main__':
	curses.wrapper(test_loop)
	print "The circle is now complete"
