#!/usr/bin/env python
# encoding: utf-8
"""
NPSAppManaged.py
"""
import NPSApp
import Form
import weakref

class NPSAppManaged(NPSApp.NPSApp):
    STARTING_FORM = "MAIN"
    def __init__(self):
        super(NPSAppManaged, self).__init__()    
        self.ACTIVE_FORM = self.__class__.STARTING_FORM
        self._Forms = {}
    
    def addForm(self, name, fm):
        fm.parentApp = weakref.proxy(self)
        self._Forms[name] = fm
        
    def removeForm(self, name):
        del self._Forms[name] 

    def main(self):
        self.onStart()
        while self.ACTIVE_FORM != "" and self.ACTIVE_FORM != None:
            self._Forms[self.ACTIVE_FORM].edit()
        self.onCleanExit()
        
    def onStart(self):
        """Override this method to perform any initialisation."""
        pass
                
    def onCleanExit(self):
        """Override this method to perform any cleanup when application is exiting without error."""
        
def main():
    T = NPSAppManaged()


if __name__ == '__main__':
    main()

