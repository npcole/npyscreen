#!/usr/bin/python
# encoding: utf-8

import sys
import os
import multiline
import Form
import weakref


class Menu(object):
	def __init__(self, name=None, show_atx=None, show_aty=None):
		self.__menu_items = []
		self.name = name
		self.__show_atx = show_atx
		self.__show_aty = show_aty
		
	def add_item(self, text, func):
		self.__menu_items.append((text, func))
	
	def set_menu(self, pairs):
		"""Pass in a list of pairs of text labels and functions"""
		for pair in pairs:
			self.add_item(pair[0], pair[1])
		
	def edit(self, *args, **keywords):
		"""Display choice to user, execute function associated"""
		
		menu_text = [x[0] for x in self.__menu_items]
		
		longest_text = 0
		#Slightly different layout if we are showing a title
		if self.name: longest_text=len(self.name)+2
		for item in menu_text: 
			if len(item) > longest_text:
				longest_text = len(item)
		
		height = len(menu_text)
		if self.name:
			height +=3
		else:
			height +=2
		
		if height > 14: 
			height = 13
		
		atx = self.__show_atx or 20
		aty = self.__show_aty or 2
		
		popup = Form.Form(name=self.name, 
			lines=height, columns=longest_text+4,
				show_aty=aty, show_atx=atx)
		if not self.name: popup.nextrely = 1
		l = popup.add(multiline.MultiLine, values=menu_text)
		
		popup.display()
		l.edit()
		if l.value is not None:
			self.__menu_items[l.value][1]()

def main(*args):
	mnu = Menu(name="Menu")
	mnu.add_item("Do Nothing", tstDoNothing)
	mnu.add_item("Do Nothing 2", tstDoNothing)
	mnu.add_item("Do Nothing 3", tstDoNothing)
	for x in range(10):
		mnu.add_item("Do Nothing x", tstDoNothing)
	mnu.edit()

def tstDoNothing():
	curses.beep()
	


if __name__ == '__main__':
	import curses.wrapper
	import curses
	curses.wrapper(main)
