#!/usr/bin/python
import widget
import textbox
import curses
import textwrap
import re

class MultiLineEdit(widget.Widget):
	def __init__(self, screen, autowrap=True, slow_scroll=True, scroll_exit=True, value=None, **keywords):
		self.value = value or ''
		super(MultiLineEdit, self).__init__(screen, **keywords)
		self.cursor_position = 0
		self.start_display_at = 0 #Line number

		self.maximum_display_width  = self.width
		self.maximum_display_height = self.height
		self.slow_scroll = slow_scroll
		self.scroll_exit = scroll_exit

		self.autowrap = autowrap
		self.wrapon = re.compile("\s+|-+")

	def get_value_as_list(self, upto=None, keepends=False):
		if upto:
			text = self.value[:upto]
		else:
			text = self.value
		if upto:
			lines = text.splitlines(keepends)
		else:
			lines = text.splitlines()
		return lines

	def translate_cursor(self, y):
		"""Translate cursor position from point in a str to y,x on in widget (you'll need to add in rely, relx yourself)"""
		if self.value == "": return 0,0
		position = y
		if position == 0: 
			return 0,0
		text_to_cursor = self.get_value_as_list(upto=position, keepends=True)
		y = (len(text_to_cursor))-1
		x = len(text_to_cursor[-1])
		if text_to_cursor[-1][-1] == '\n': 
			y += 1
			x = 0
		return y, x
			
	def calculate_area_needed(self):
		return 0,0

	def update(self, clear=True):
	
		if clear: self.clear()
		display_length = self.height
		display_width = self.width
		xdisplay_offset = 0
		text_to_display = self.get_value_as_list()
		if self.cursor_position < 0: self.cursor_position = 0
		if self.cursor_position > len(self.value): self.cursor_position = len(self.value)

		self.cursory, self.cursorx = self.translate_cursor(self.cursor_position)
	
		if self.editing:
			if self.slow_scroll:
				if self.cursory > self.start_display_at+display_length-1:
					self.start_display_at = self.cursory - (display_length-1) 

				if self.cursory < self.start_display_at:
					self.start_display_at = self.cursory
			
			else:
				if self.cursory > self.start_display_at+(display_length-1):
					self.start_display_at = self.cursory

				if self.cursory < self.start_display_at:
					self.start_display_at = self.cursory - (display_length-1)
			
			if self.start_display_at < 0:
				self.start_display_at=0

			if self.cursorx > display_width:
				xdisplay_offset = self.cursorx - display_width
		
		max_display = len(text_to_display[self.start_display_at:])

		for line_counter in range(self.height):
			if line_counter >= len(text_to_display)-self.start_display_at: break
			self.parent.curses_pad.addnstr(self.rely+line_counter, self.relx, 
				text_to_display[self.start_display_at+line_counter][xdisplay_offset:], display_width)
			

		if self.editing:
			# Cursors do not seem to work on pads.
			#self.parent_screen.move(self.rely, self.cursor_position - self.begin_at)
			# let's have a fake cursor
			_cur_y, _cur_x = self.translate_cursor(self.cursor_position)
			_cur_y += self.rely - self.start_display_at
			assert _cur_y >= 0
			_cur_x += self.relx - xdisplay_offset
			char_under_cur = self.parent.curses_pad.inch(_cur_y, _cur_x)
			self.parent.curses_pad.addch(_cur_y, _cur_x, char_under_cur, curses.A_STANDOUT)

	def reformat_preserve_nl(self, *ignorethese):
		# Adapted from a script found at:
		#http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/148061
		width=self.width
		text = self.value
		self.value = reduce(lambda line, word, width=width: '%s%s%s' %
				  (line,
				   ' \n'[(len(line)-line.rfind('\n')-1
					 + len(word.split('\n',1)[0]
					      ) >= width)],
				   word),
				  text.split(' ')
				 )

	def full_reformat(self, *args):
		w = DocWrapper(width=self.width)
		self.value = w.fill(self.value)
		
	######################################################################
	def set_up_handlers(self):
		super(MultiLineEdit, self).set_up_handlers()	
	
		# For OS X
		del_key = curses.ascii.alt('~')
		
		self.handlers.update({
			       curses.ascii.NL:	   self.h_add_nl,
			       curses.ascii.CR:	   self.h_add_nl,
			       curses.KEY_LEFT:    self.h_cursor_left,
	                       curses.KEY_RIGHT:   self.h_cursor_right,
			       curses.KEY_UP:	   self.h_line_up,
			       curses.KEY_DOWN:	   self.h_line_down,
			       curses.KEY_DC:	   self.h_delete_right,
			       curses.ascii.DEL:   self.h_delete_left,
			       curses.ascii.BS:    self.h_delete_left,
			       curses.KEY_BACKSPACE: self.h_delete_left,
			       "^R":		   self.full_reformat,
			       # mac os x curses reports DEL as escape oddly
			       # no solution yet			       
			       #"^K":		   self.h_erase_right,
			       #"^U":		   self.h_erase_left,
			})

		self.complex_handlers.extend((
                                             (self.t_input_isprint, self.h_addch),
		                            # (self.t_is_ck, self.h_erase_right),
					    # (self.t_is_cu, self.h_erase_left),
					    ))

	def t_input_isprint(self, input):
		if curses.ascii.isprint(input) and \
		(chr(input) not in '\n\t\r'): 
			return True
		
		else: return False

	def h_addch(self, input):
		"""Add printable characters.  However, do NOT add newlines with this function"""
		if not self.editable: return False
		self.value = self.value[:self.cursor_position] + chr(input) \
			+ self.value[self.cursor_position:]
		self.cursor_position += len(chr(input))
		
		if self.autowrap:
			self.reformat_preserve_nl()

	
	def h_line_down(self, input):
		self.cursor_position = self.value.find("\n", self.cursor_position) 
		if self.cursor_position == -1:
			if self.scroll_exit: self.h_exit_down(None)
			else: self.cursor_position = len(self.value)
		else: self.cursor_position += 1

	def h_line_up(self, input):
		self.cursor_position = self.value.rfind("\n", 0, self.cursor_position) 
		if self.cursor_position == -1:
			if self.scroll_exit: self.h_exit_up(None)
			else: self.cursor_position = 0
	
	def h_add_nl(self, input):
		self.value = self.value[:self.cursor_position] + "\n" + self.value[self.cursor_position:]
		self.cursor_position += 1

	def h_cursor_left(self, input):
		if self.cursor_position > 0: 
			self.cursor_position -= 1
		

	def h_cursor_right(self, input):
		self.cursor_position += 1

	def h_delete_left(self, input):
		if self.editable and self.cursor_position > 0:
			self.value = self.value[:self.cursor_position-1] + self.value[self.cursor_position:]
		
		self.cursor_position -= 1

	def h_delete_right(self, input):
		if self.editable:
			self.value = self.value[:self.cursor_position] + self.value[self.cursor_position+1:]

class DocWrapper(textwrap.TextWrapper):
    """Wrap text in a document, processing each paragraph individually"""
	# Code from http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/358228
    def wrap(self, text):
        """Override textwrap.TextWrapper to process 'text' properly when
        multiple paragraphs present"""
        para_edge = re.compile(r"(\n\s*\n)", re.MULTILINE)
        paragraphs = para_edge.split(text)
        wrapped_lines = []
        for para in paragraphs:
            if para.isspace():
                if not self.replace_whitespace:
                    # Do not take the leading and trailing newlines since
                    # joining the list with newlines (as self.fill will do)
                    # will put them back in.
                    if self.expand_tabs:
                        para = para.expandtabs()
                    wrapped_lines.append(para[1:-1])
                else:
                    # self.fill will end up putting in the needed newline to
                    # space out the paragraphs
                    wrapped_lines.append('')
            else:
                wrapped_lines.extend(textwrap.TextWrapper.wrap(self, para))
        return wrapped_lines

		
def testme(sa):
	import screen_area
	import textbox
	SA = screen_area.ScreenArea()
	w = MultiLineEdit(SA, relx=5, rely=3, value="This\nis something of a test\nThis is line2", 
		max_height=5, max_width=70, slow_scroll=True)
	w.slow_scroll=False
	w.autowrap = True
	w.edit()
	w.display()

if __name__ == '__main__':
	curses.wrapper(testme)
	print "Your powers are weak, old man"
